﻿namespace Bloxstrap.UI.Elements.About.Pages
{
    /// <summary>
    /// Interaction logic for TranslatorsPage.xaml
    /// </summary>
    public partial class TranslatorsPage
    {
        public TranslatorsPage()
        {
            InitializeComponent();
        }
    }
}
