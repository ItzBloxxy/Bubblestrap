﻿namespace Bloxstrap.Enums
{
    public enum EmojiType
    {
        Default,
        Catmoji,
        Windows11,
        Windows10,
        Windows8
    }
}
